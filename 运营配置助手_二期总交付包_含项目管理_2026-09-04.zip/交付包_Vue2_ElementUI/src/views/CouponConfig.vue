<template>
  <section class="coupon-workspace">
    <header class="page-head">
      <div>
        <div class="breadcrumb"><span>运营管理</span><i class="el-icon-arrow-right" />App优惠券管理</div>
        <h1 class="page-title">App优惠券管理</h1>
        <p class="page-description">先选班型商品，再按项目和科室批量勾选专业，一次性生成实际生效的「商品 × 专业」优惠券。</p>
      </div>
      <el-button @click="$router.push('/business-lines')">从全部项目清单选择</el-button>
    </header>

    <el-alert
      v-if="transfer.source"
      class="transfer-alert"
      type="success"
      show-icon
      :closable="false"
      :title="`已从${transfer.source}带入 ${productIds.length} 个商品、${professionIds.length} 个专业`"
    />

    <aside class="intro-banner" aria-label="当前改造说明">
      <p><strong>当前痛点</strong>人工给中级职称约 39 个专业逐条取名、勾选、分配优惠券，实测要 2–3 小时，专业数还会继续增加。</p>
      <p><strong>这次怎么做</strong>先从可搜索的商品列表选定班型，再按科室分组一键勾选专业，一次性生成全部优惠券。</p>
      <p><strong>演示任务</strong>勾选「2027年中级职称精英班」，再展开「中级职称」全选内科类——「中医内科」会标红，因为该商品不覆盖此专业。</p>
    </aside>

    <div class="workspace-grid">
      <div class="config-panel">
        <div class="panel-title">优惠券批量配置</div>

        <div class="field-row">
          <label class="field-label" for="coupon-name"><span class="req">*</span>优惠券名称</label>
          <el-input id="coupon-name" v-model.trim="form.name" maxlength="30" show-word-limit placeholder="例如：中级职称精英班暑期立减券" />
        </div>

        <div class="field-row">
          <div class="field-label"><span class="req">*</span>优惠方式</div>
          <div class="mode-toggle" role="radiogroup" aria-label="优惠方式">
            <button
              v-for="item in modes"
              :key="item.value"
              type="button"
              :class="['mode-btn', { active: form.type === item.value }]"
              :aria-pressed="form.type === item.value"
              @click="form.type = item.value"
            >{{ item.label }}</button>
          </div>
          <div class="rule-line">
            <template v-if="form.type === 'FULL'">
              <span>满</span>
              <el-input-number v-model="form.threshold" :min="0" :precision="2" controls-position="right" />
              <span>元减</span>
              <el-input-number v-model="form.amount" :min="0" :precision="2" controls-position="right" />
              <span>元</span>
            </template>
            <template v-else-if="form.type === 'DISCOUNT'">
              <span>打</span>
              <el-input-number v-model="form.discount" :min="1" :max="9.9" :step="0.1" :precision="1" controls-position="right" />
              <span>折（即优惠 {{ discountOff }}%）</span>
            </template>
            <template v-else>
              <span>无门槛直减</span>
              <el-input-number v-model="form.amount" :min="1" :precision="2" controls-position="right" />
              <span>元</span>
            </template>
          </div>
        </div>

        <div class="field-row">
          <div class="field-label"><span class="req">*</span>所属课程（班型商品）</div>
          <div class="course-toolbar">
            <el-input v-model.trim="courseKeyword" clearable prefix-icon="el-icon-search" placeholder="搜索班型商品，如「精英班」「早鸟」…" />
            <el-button type="primary" @click="showAddCourse = !showAddCourse">＋ 新增商品</el-button>
          </div>
          <div v-if="showAddCourse" class="add-course">
            <el-input v-model.trim="newCourse.name" placeholder="商品名称，如「2027年中级职称冲刺押题班」" />
            <el-select v-model="newCourse.category" style="width:100%">
              <el-option v-for="item in middleCategories" :key="item" :label="item" :value="item" />
            </el-select>
            <p class="add-hint">新商品默认沿用中级职称 19 个专业覆盖范围，如需调整需技术侧另行配置。</p>
            <div class="add-actions">
              <el-button size="small" @click="cancelAddCourse">取消</el-button>
              <el-button size="small" type="primary" @click="addCourse">确定添加</el-button>
            </div>
          </div>
          <div class="course-list">
            <template v-for="group in groupedCourses">
              <div :key="group.key" class="course-group-header">{{ group.label }}（{{ group.total }}）</div>
              <button
                v-for="course in group.items"
                :key="course.id"
                type="button"
                :class="['course-row', { checked: productIds.includes(course.id) }]"
                @click="toggleCourse(course.id)"
              >
                <span class="box" :aria-hidden="true" />
                <span class="course-name">{{ course.name }}</span>
                <span class="course-tag">覆盖 {{ course.scope.length }} 个专业</span>
                <span class="remove" title="移除该商品" @click.stop="removeCourse(course)">✕</span>
              </button>
            </template>
            <div v-if="!groupedCourses.length" class="course-empty">没有找到匹配的商品，换个关键词试试</div>
          </div>
          <div v-if="selectedCourses.length" class="selected-chips">
            <span v-for="course in selectedCourses" :key="course.id" class="chip">
              {{ course.name }}
              <button type="button" aria-label="取消该商品" @click="toggleCourse(course.id)">×</button>
            </span>
          </div>
          <p class="field-note">商品列表支持搜索定位和多选。优惠券实际作用于「已选课程 × 已选专业」的组合。</p>
        </div>

        <div class="field-row">
          <div class="field-label"><span class="req">*</span>所属专业（点击业务大类展开）</div>
          <div v-if="professionIds.length" class="quick-clear">
            <el-button v-if="impact.mismatched.length" size="small" @click="clearMismatch">✕ 清空不适用项（{{ impact.mismatched.length }}）</el-button>
            <el-button size="small" @click="clearProfessions">清空全部已选专业</el-button>
          </div>
          <p v-if="clickCompare" class="click-compare" v-html="clickCompare" />
          <div class="cat-list">
            <article v-for="category in taxonomy" :key="category.name" class="cat-card">
              <div class="cat-header" @click="toggleOpen(category.name)">
                <el-checkbox
                  :value="isCategoryAllSelected(category)"
                  :indeterminate="isCategoryIndeterminate(category)"
                  :aria-label="`选择${category.name}全部专业`"
                  @click.native.stop
                  @change="toggleCategory(category, $event)"
                />
                <strong>{{ category.name }}</strong>
                <span class="cat-count">（{{ categoryTotal(category) }}个）</span>
                <em v-if="categorySelected(category)">已选 {{ categorySelected(category) }}</em>
                <i :class="['el-icon-arrow-down', { open: isOpen(category.name) }]" />
              </div>
              <div v-show="isOpen(category.name)" class="cat-body">
                <p v-if="hasNamedGroups(category)" class="cat-new">支持按科室分组批量勾选（共 {{ categoryTotal(category) }} 个专业）</p>
                <div v-if="hasNamedGroups(category)" class="sub-tags">
                  <button
                    v-for="group in category.groups"
                    :key="group.name"
                    type="button"
                    :class="['sub-tag', { active: isGroupAllSelected(category, group) }]"
                    @click.stop="toggleGroup(category, group)"
                  >{{ group.name }}<small>（{{ group.items.length }}）</small></button>
                </div>
                <div v-for="group in category.groups" :key="group.name || category.name">
                  <div v-if="group.name" class="sub-head">{{ group.name }}</div>
                  <div class="chip-list">
                    <button
                      v-for="item in group.items"
                      :key="item"
                      type="button"
                      :class="['prof-chip', { checked: professionIds.includes(makeId(category.name, item)), mismatch: isMismatch(makeId(category.name, item)) }]"
                      @click.stop="toggleProfession(makeId(category.name, item), true)"
                    >
                      {{ item }}
                      <small v-if="isMismatch(makeId(category.name, item))">所选商品不覆盖该专业</small>
                    </button>
                  </div>
                </div>
              </div>
            </article>
          </div>
        </div>

        <div class="field-row">
          <label class="field-label"><span class="req">*</span>生效时间</label>
          <el-date-picker v-model="form.startAt" type="datetime" value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择生效时间" />
        </div>
        <div class="field-row">
          <label class="field-label"><span class="req">*</span>截止时间</label>
          <el-date-picker v-model="form.endAt" type="datetime" value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择截止时间" />
          <p v-if="dateInvalid" class="date-warning">截止时间不能早于生效时间</p>
        </div>

        <el-button type="primary" class="save-btn" :loading="submitting" @click="submit">保存配置</el-button>
        <p class="save-note">已选 <b>{{ professionIds.length }}</b> 个专业，实际将生成 <b>{{ impact.combinationCount }}</b> 张优惠券</p>
      </div>

      <aside class="side-column">
        <p class="side-label">AI 变更摘要</p>
        <div class="ai-card" aria-live="polite">
          <div class="ai-eyebrow"><span class="dot" />AI 自动生成 · 最近 7 天</div>
          <div class="ai-text" v-html="aiSummary" />
        </div>
        <p class="side-label">变更记录</p>
        <div class="log-panel">
          <div v-for="(item, index) in logs" :key="`${item.time}-${index}`" :class="['log-item', item.tone]">
            <div class="log-time">{{ item.time }} · {{ item.user }}</div>
            <div class="log-text">{{ item.content }}</div>
            <div v-if="item.tag" class="log-tag">{{ item.tag }}</div>
          </div>
        </div>
      </aside>
    </div>
  </section>
</template>

<script>
import { allOperationProducts, getImpact, professionProject, readTransfer, taxonomy, zzzcScope } from '../data/phase1Business'

const eliteName = '2027年中级职称精英班'

export default {
  name: 'CouponConfig',
  data () {
    const transfer = readTransfer()
    const products = allOperationProducts.map(item => ({ ...item, scope: item.scope.slice() }))
    const transferredProducts = Array.isArray(transfer.products) ? transfer.products : []
    const defaultProduct = products.find(item => item.name === eliteName)
    return {
      transfer,
      taxonomy,
      products,
      productIds: transferredProducts.length ? transferredProducts : (defaultProduct ? [defaultProduct.id] : []),
      professionIds: Array.isArray(transfer.professions) ? transfer.professions : [],
      courseKeyword: '',
      showAddCourse: false,
      middleCategories: ['刷题必买', '高端进阶', '高分密训', '基础夯实'],
      newCourse: { name: '', category: '刷题必买' },
      opened: ['中级职称'],
      tagClickCount: 0,
      manualClickCount: 0,
      modes: [
        { value: 'FULL', label: '满减' },
        { value: 'DISCOUNT', label: '按比例折扣' },
        { value: 'DIRECT', label: '自定义直减' }
      ],
      form: {
        name: '中级职称精英班暑期立减券',
        type: 'FULL',
        threshold: 0,
        amount: 980,
        discount: 8,
        startAt: '2026-07-20 09:00:00',
        endAt: '2026-07-31 23:59:59'
      },
      submitting: false,
      aiOverride: '',
      logs: [
        { time: '07-13 09:12', user: '运营-王倩', content: '修改「内科主治」优惠券金额：50 → 80', tone: 'warn', tag: '短时间重复修改' },
        { time: '07-12 16:40', user: '运营-陈昊', content: '新增「外科类」暑期优惠券配置，覆盖 10 个专业', tone: '', tag: '' },
        { time: '07-11 11:03', user: '运营-王倩', content: '修改「内科主治」优惠券金额：80 → 50', tone: '', tag: '' }
      ]
    }
  },
  computed: {
    selectedCourses () { return this.products.filter(item => this.productIds.includes(item.id)) },
    catalogProducts () {
      const middle = this.products.filter(item => item.project === '中级职称')
      const extras = this.products.filter(item => item.project !== '中级职称' && this.productIds.includes(item.id))
      return middle.concat(extras)
    },
    groupedCourses () {
      const term = this.courseKeyword.toLowerCase()
      const groups = []
      this.catalogProducts.forEach(item => {
        const label = item.project === '中级职称' ? item.category : `${item.project} · ${item.ownerLabel || item.category}`
        const key = `${item.project}::${label}`
        let group = groups.find(current => current.key === key)
        if (!group) {
          group = { key, label, total: 0, items: [] }
          groups.push(group)
        }
        group.total += 1
        if (!term || item.name.toLowerCase().includes(term)) group.items.push(item)
      })
      return groups.filter(group => group.items.length)
    },
    impact () { return getImpact(this.productIds, this.professionIds, this.products) },
    discountOff () { return Math.max(0, Math.round((10 - Number(this.form.discount || 0)) * 10) / 10) },
    discountSummary () {
      if (this.form.type === 'DISCOUNT') return `${this.form.discount}折`
      if (this.form.type === 'DIRECT') return `无门槛直减${this.form.amount}元`
      return `满${this.form.threshold}减${this.form.amount}`
    },
    dateInvalid () {
      return this.form.startAt && this.form.endAt && new Date(this.form.endAt).getTime() <= new Date(this.form.startAt).getTime()
    },
    clickCompare () {
      const n = this.professionIds.length
      const totalClicks = this.tagClickCount + this.manualClickCount
      if (!n || !totalClicks) return ''
      const saved = Math.max(n - totalClicks, 0)
      return `改造前（逐个勾选）：需点击 <b>${n}</b> 次　→　改造后（本次实际点击）：<b>${totalClicks}</b> 次　→　减少 <b>${saved}</b> 次重复操作`
    },
    aiSummary () {
      if (this.aiOverride) return this.aiOverride
      if (!this.productIds.length || !this.professionIds.length) {
        return '请选择专业、适用课程和优惠方式，这里会实时预览本次配置的覆盖范围。'
      }
      const cats = Array.from(new Set(this.professionIds.map(professionProject)))
      const flagged = this.professionIds.some(id => id.includes('内科主治(303)'))
      const flagText = flagged ? '其中 <b>1</b> 个专业的优惠券近 7 天内曾被频繁修改，建议留意是否重复操作。' : ''
      const mismatchText = this.impact.mismatched.length
        ? `<br>其中 <b>${this.impact.mismatched.length}</b> 个专业（${this.impact.mismatched.map(item => item.name).join('、')}）不在已选商品的覆盖范围内，不会生成优惠券。`
        : ''
      return `已选择 <b>${this.professionIds.length}</b> 个专业（跨 ${cats.length} 个业务大类：${cats.join('、')}） × <b>${this.productIds.length}</b> 个课程，实际将生成 <b>${this.impact.combinationCount}</b> 张「${this.discountSummary}」优惠券。${flagText}${mismatchText}`
    }
  },
  methods: {
    makeId (category, item) { return `${category}::${item}` },
    categoryIds (category) { return category.groups.reduce((ids, group) => ids.concat(group.items.map(item => this.makeId(category.name, item))), []) },
    categoryTotal (category) { return this.categoryIds(category).length },
    categorySelected (category) { return this.categoryIds(category).filter(id => this.professionIds.includes(id)).length },
    isCategoryAllSelected (category) { const ids = this.categoryIds(category); return ids.length > 0 && ids.every(id => this.professionIds.includes(id)) },
    isCategoryIndeterminate (category) { const count = this.categorySelected(category); return count > 0 && count < this.categoryIds(category).length },
    isGroupAllSelected (category, group) { return group.items.every(item => this.professionIds.includes(this.makeId(category.name, item))) },
    hasNamedGroups (category) { return category.groups.some(group => group.name) },
    isOpen (name) { return this.opened.includes(name) },
    isMismatch (id) { return this.professionIds.includes(id) && this.impact.mismatched.some(item => item.professionId === id) },
    toggleOpen (name) { this.opened = this.isOpen(name) ? this.opened.filter(item => item !== name) : this.opened.concat(name) },
    setProfessions (value) { this.professionIds = value },
    toggleCourse (id) {
      this.productIds = this.productIds.includes(id) ? this.productIds.filter(item => item !== id) : this.productIds.concat(id)
    },
    toggleProfession (id, manual) {
      if (manual) this.manualClickCount += 1
      this.setProfessions(this.professionIds.includes(id) ? this.professionIds.filter(item => item !== id) : this.professionIds.concat(id))
    },
    toggleCategory (category, checked) {
      this.tagClickCount += 1
      const ids = this.categoryIds(category)
      this.setProfessions(checked ? Array.from(new Set(this.professionIds.concat(ids))) : this.professionIds.filter(id => !ids.includes(id)))
    },
    toggleGroup (category, group) {
      this.tagClickCount += 1
      const ids = group.items.map(item => this.makeId(category.name, item))
      const all = ids.every(id => this.professionIds.includes(id))
      this.setProfessions(all ? this.professionIds.filter(id => !ids.includes(id)) : Array.from(new Set(this.professionIds.concat(ids))))
    },
    clearMismatch () {
      const ids = this.impact.mismatched.map(item => item.professionId)
      this.setProfessions(this.professionIds.filter(id => !ids.includes(id)))
    },
    clearProfessions () {
      this.tagClickCount = 0
      this.manualClickCount = 0
      this.setProfessions([])
    },
    addCourse () {
      if (!this.newCourse.name) return this.$message.warning('请填写商品名称')
      if (this.products.some(item => item.name === this.newCourse.name)) return this.$message.warning('该商品名称已存在，请换一个名称')
      const product = {
        id: `zzzc-new-${Date.now()}`,
        name: this.newCourse.name,
        project: '中级职称',
        category: this.newCourse.category,
        scope: zzzcScope.slice(),
        price: null,
        status: 'OFF',
        source: '中级职称课程库'
      }
      this.products.unshift(product)
      this.productIds = this.productIds.concat(product.id)
      this.cancelAddCourse()
      this.$message.success('商品已新增并自动选中')
    },
    cancelAddCourse () {
      this.showAddCourse = false
      this.newCourse = { name: '', category: '刷题必买' }
    },
    removeCourse (course) {
      this.$confirm(`确认从商品列表中移除「${course.name}」？此操作仅影响本次演示清单，不会影响真实后台数据。`, '移除商品', { type: 'warning', confirmButtonText: '确认移除', cancelButtonText: '取消' }).then(() => {
        this.products = this.products.filter(item => item.id !== course.id)
        this.productIds = this.productIds.filter(id => id !== course.id)
        this.$message.success('商品已移除')
      }).catch(() => {})
    },
    submit () {
      if (!this.form.name) return this.$message.warning('请填写优惠券名称')
      if (this.form.type === 'FULL' && Number(this.form.amount) > Number(this.form.threshold) && Number(this.form.threshold) > 0) {
        return this.$message.warning('满减金额应小于使用门槛')
      }
      if (!this.productIds.length) return this.$message.warning('请先勾选至少一个适用课程')
      if (!this.professionIds.length) return this.$message.warning('请先勾选至少一个专业')
      if (!this.form.startAt || !this.form.endAt) return this.$message.warning('请填写生效时间和截止时间')
      if (this.dateInvalid) return this.$message.error('截止时间不能早于生效时间，请检查日期')
      if (!this.impact.combinationCount) return this.$message.error('已选专业均不在所选商品的覆盖范围内，无法生成优惠券')
      const cats = Array.from(new Set(this.professionIds.map(professionProject))).join('、')
      const courses = this.selectedCourses.map(item => item.name).join('、')
      const skipped = this.impact.mismatched.length ? `\n以下 ${this.impact.mismatched.length} 个专业不在覆盖范围内，将被跳过：${this.impact.mismatched.map(item => item.name).join('、')}` : ''
      this.$confirm(
        `涉及业务大类：${cats}\n优惠方式：${this.discountSummary}\n适用课程：${courses}（${this.productIds.length} 个）\n有效期：${this.form.startAt} 至 ${this.form.endAt}\n实际将生成优惠券：${this.impact.combinationCount} 张${skipped}`,
        '确认批量配置优惠券？',
        { confirmButtonText: '确认保存', cancelButtonText: '返回检查', type: 'warning' }
      ).then(() => {
        this.submitting = true
        this.aiOverride = '正在生成摘要…'
        window.setTimeout(() => {
          this.logs.unshift({
            time: '07-16 09:32',
            user: '运营-美惠',
            content: `批量配置优惠券（${this.discountSummary}，有效期 ${this.form.startAt} 至 ${this.form.endAt}），涉及「${cats}」，适用课程：${courses}，共生成 ${this.impact.combinationCount} 张${this.impact.mismatched.length ? `（${this.impact.mismatched.length}个专业因不在覆盖范围内被跳过）` : ''}`,
            tone: 'new',
            tag: ''
          })
          this.aiOverride = `刚刚，<b>你</b> 一次性批量配置了「${cats}」的优惠券（${this.discountSummary}，有效期 ${this.form.startAt} 至 ${this.form.endAt}），适用课程：${courses}，共生成 <b>${this.impact.combinationCount}</b> 张，相比逐个专业逐个课程手动勾选，节省大量重复操作。此外，「内科主治」优惠券近 7 天内被修改 3 次，金额来回波动，建议核实是否为误操作。`
          this.submitting = false
          this.$message.success(`已生成 ${this.impact.combinationCount} 张优惠券配置`)
        }, 600)
      }).catch(() => {})
    }
  }
}
</script>

<style scoped>
.coupon-workspace{max-width:1180px;margin:0 auto}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:24px}.breadcrumb{margin-bottom:10px;color:#8a919e;font-size:12px}.breadcrumb span{color:#5f6876}.breadcrumb i{margin:0 7px}.transfer-alert{margin-top:16px}.intro-banner{margin:16px 0 18px;padding:14px 16px;border:1px solid var(--line);border-radius:10px;background:#fff}.intro-banner p{display:grid;grid-template-columns:78px 1fr;gap:10px;margin:0 0 6px;color:var(--muted);line-height:1.7}.intro-banner p:last-child{margin:8px 0 0;padding-top:8px;border-top:1px dashed var(--line);color:#166350}.intro-banner strong{color:var(--ink)}.workspace-grid{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(280px,.75fr);gap:18px;align-items:start}.config-panel,.log-panel{padding:22px 24px;border:1px solid var(--line);border-radius:10px;background:#fff}.panel-title{margin-bottom:18px;font-size:14px;font-weight:700}.field-row{margin-bottom:20px}.field-label{display:block;margin-bottom:8px;font-weight:600}.req{margin-right:3px;color:#c91420}.mode-toggle{display:flex;gap:8px;margin-bottom:10px}.mode-btn{flex:1;min-height:38px;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:#fff;color:var(--muted);font-weight:700;cursor:pointer}.mode-btn.active{border-color:var(--brand);background:var(--brand-soft);color:#a90a13}.rule-line{display:flex;align-items:center;flex-wrap:wrap;gap:8px;color:var(--muted)}.rule-line .el-input-number{width:120px}.course-toolbar{display:flex;gap:8px;margin-bottom:8px}.course-toolbar .el-input{flex:1}.add-course{display:flex;flex-direction:column;gap:8px;margin-bottom:8px;padding:12px;border:1px dashed #eba5aa;border-radius:8px;background:#fff8f8}.add-hint{margin:0;color:#a90a13;font-size:12px}.add-actions{display:flex;justify-content:flex-end;gap:8px}.course-list{max-height:220px;overflow:auto;border:1px solid var(--line);border-radius:6px;background:#fff}.course-group-header{position:sticky;top:0;padding:6px 12px;border-bottom:1px solid var(--line);background:#fafafa;color:var(--muted);font-size:11px;font-weight:700}.course-row{display:flex;align-items:center;gap:9px;width:100%;padding:8px 12px;border:0;border-bottom:1px solid #f0f0f0;background:#fff;text-align:left;cursor:pointer}.course-row:last-child{border-bottom:0}.course-row:hover{background:#fafafa}.course-row.checked{background:var(--brand-soft)}.box{width:14px;height:14px;flex-shrink:0;border:1px solid #c5cbd3;border-radius:3px;background:#fff}.course-row.checked .box{border-color:var(--brand);background:var(--brand);box-shadow:inset 0 0 0 2px #fff}.course-name{flex:1}.course-tag{flex-shrink:0;padding:1px 7px;border-radius:8px;background:#f0f0f0;color:var(--muted);font-size:10px}.remove{display:none;width:18px;height:18px;border-radius:50%;background:#edeef0;color:var(--muted);font-size:11px;line-height:18px;text-align:center}.course-row:hover .remove{display:inline-block}.remove:hover{background:var(--brand);color:#fff}.course-empty{padding:16px;color:var(--muted);text-align:center}.selected-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.chip{display:flex;align-items:center;gap:5px;padding:4px 9px;border-radius:14px;background:var(--brand-soft);color:#a90a13;font-size:12px;font-weight:600}.chip button{padding:0;border:0;background:transparent;color:inherit;cursor:pointer}.field-note,.save-note{margin:6px 0 0;color:var(--muted);font-size:12px}.quick-clear{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px}.click-compare{margin:0 0 8px;padding:8px 10px;border-radius:6px;background:#fafafa;color:var(--muted);font-size:12px;line-height:1.6}.click-compare >>> b{color:#166350}.cat-card{margin-bottom:8px;overflow:hidden;border:1px solid var(--line);border-radius:8px}.cat-header{display:flex;align-items:center;gap:10px;padding:11px 14px;cursor:pointer}.cat-header:hover{background:#fafafa}.cat-count{color:var(--muted);font-size:12px}.cat-header em{margin-left:auto;margin-right:8px;color:#166350;font-size:11px;font-style:normal;font-weight:700}.el-icon-arrow-down{color:#8a919e;transition:transform .18s ease}.el-icon-arrow-down.open{transform:rotate(180deg)}.cat-body{padding:0 14px 12px;border-top:1px solid var(--line)}.cat-new{display:inline-block;margin:8px 0 6px;padding:2px 8px;border-radius:8px;background:#e4f2ec;color:#166350;font-size:11px;font-weight:700}.sub-tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}.sub-tag{padding:5px 11px;border:1px solid #1f8a6e;border-radius:14px;background:#fff;color:#166350;font-size:12px;font-weight:600;cursor:pointer}.sub-tag.active{background:#1f8a6e;color:#fff}.sub-tag small{margin-left:2px;font-weight:500;opacity:.8}.sub-head{margin:8px 0 4px;padding-top:5px;border-top:1px dashed var(--line);color:var(--muted);font-size:11px;font-weight:700}.chip-list{display:flex;flex-wrap:wrap;gap:6px;padding-top:4px}.prof-chip{display:flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid var(--line);border-radius:6px;background:#fbfbfa;font-size:12px;cursor:pointer}.prof-chip.checked{border-color:#1f8a6e;background:#e4f2ec;color:#166350;font-weight:600}.prof-chip.mismatch{border-color:var(--brand);background:var(--brand-soft);color:#a90a13}.prof-chip small{color:#a90a13;font-size:10px;font-weight:700}.config-panel .el-date-editor{width:100%}.date-warning{margin:6px 0 0;color:#a90a13;font-size:12px}.save-btn{width:100%;margin-top:6px}.save-note{text-align:center}.side-label{margin:0 0 10px;color:var(--muted);font-size:12px;font-weight:700}.ai-card{margin-bottom:14px;padding:18px 20px;border-radius:10px;background:#1b3d37;color:#fff}.ai-eyebrow{display:flex;align-items:center;gap:6px;margin-bottom:9px;color:#8fd4bc;font-size:11px;font-weight:700}.dot{width:6px;height:6px;border-radius:50%;background:#8fd4bc;animation:pulse 1.6s ease-in-out infinite}.ai-text{font-size:13px;line-height:1.7}.ai-text >>> b{color:#8fd4bc}.log-item{padding:0 0 14px}.log-item+.log-item{border-top:1px solid var(--line);padding-top:14px}.log-time{color:var(--muted);font-size:11px}.log-text{margin-top:4px;font-size:13px;line-height:1.5}.log-item.new .log-text{color:#166350;font-weight:600}.log-tag{display:inline-block;margin-top:5px;padding:2px 7px;border-radius:5px;background:#fbf3e2;color:#b8862e;font-size:10px;font-weight:700}@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}@media(prefers-reduced-motion:reduce){.dot{animation:none}.el-icon-arrow-down{transition:none}}@media(max-width:980px){.page-head,.course-toolbar{flex-direction:column;align-items:stretch}.workspace-grid{grid-template-columns:1fr}.intro-banner p{grid-template-columns:1fr}}
</style>
